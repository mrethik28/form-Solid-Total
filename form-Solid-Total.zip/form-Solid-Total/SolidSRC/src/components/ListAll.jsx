import { For, createSignal, onMount } from "solid-js";
import Frame from "./Frame";

export default function ListAll(props)
{
    const backHome= function()
    {
        props.setListAllForms(false);
    }

    const [allRecords, setAllRecords]=createSignal([]);
    const [delID, setDelID]=createSignal();

    const setRecs = async function ()
    {
        const response = await fetch('allforms');
        if(response.ok)
        {
            const jsondata = await response.json();
            setAllRecords(jsondata);
        }
        else{
            alert("error:");
        }
    }
    setRecs();

    function setVals(row)
    {
        setDelID(row.record.id);
        props.setEditDetails(row.record);
    }
    
    const deleteForm= async function(event)
    {
        const mydelid=JSON.stringify({"delid":delID()});
        const response= await fetch('allforms',{headers:{'Content-Type':'application/json'},method:'POST',body:mydelid})
        if(response.ok){
            setRecs();
        }
        else{alert('error')}
    }

    const editForm = function()
    {
        props.setEditForm(true);
        props.setListAllForms(false);
        
    }

         
      

    return(

        <div class="w-screen h-screen bg-nicegray pt-20">
            <button onClick={backHome} type="button" class="absolute top-0 right-0 text-white bg-black p-2 text-2xl">X</button>
            {/* <!-- <div id="selected" class="w-1/2 mx-auto text-yellow-300 rounded-xl bg-black h-16 "></div> --> */}
            <div class="m-6 mt-0 w-1/4 mx-auto flex justify-around">
            
                    <button type="button" onClick={editForm} class="text-yellow-300 bg-gray-700 p-2 mt-16 rounded-xl w-full  ">
                        Edit
                    </button>
                    <button onClick={deleteForm} type="button" class="text-yellow-300 bg-gray-700 p-2 rounded-xl w-full mt-16  ">
                        Delete
                    </button>
            </div> 
            <div id="mytable" class="absolute bottom-16 left-96 right-96 shadow-lg overflow-scroll shadow-black content-start w-1/2 h-3/5 m-auto grid grid-cols-1 grid-auto auto-cols-auto gap-x-8 gap-y-4 bg-gradient-to-b from-nicegray to-gray-800 rounded-2xl p-6 text-yellow-300">
        
                <div class="flex flex-nowrap w-full justify-between cursor-pointer">
                    <div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">Name</div>    
                    <div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">Phone</div>    
                    <div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">eMail</div>    
                    <div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">Gender</div>    
                    <div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">id</div>    
        
                </div>    

                <div>
                    <For each={allRecords()}>{(record) => (
                    <div class="flex focus:ring-2 focus:ring-white focus:ring-opacity-50 active:ring-2 active:ring-white active:ring-opacity-50 my-2 w-full justify-between cursor-pointer border-solid border-10 border-black rounded-xl px-2" onclick={() => setVals({record})}>

                        <a>{record.name}</a>
                        <a>{record.phonenum}</a>
                        <a>{record.email}</a>
                        <a>{record.gender}</a>
                        <a>{record.id}</a>
                        <a>{record.contents}</a>
                    </div>
                    )}</For>
                </div>
            </div>
        </div>   
    );
}


