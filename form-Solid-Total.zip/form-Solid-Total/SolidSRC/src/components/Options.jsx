import App from "../App";
export default function Options(props)
{
    const gotoFind= function()
    {
        props.setNeedForm(true);
    }
    return(
        <div class=" w-2/5 flex justify-between absolute bottom-1/6 lg:bottom-4 mx-auto mt-12 lg:mt-16">
            <a id="" href="/yourforms" onClick={gotoFind} class="w-2/5 text-center text-sm lg:text-xl rounded-xl  p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">
                View Submitted Forms
            </a>
            <a id="" href="/allforms" class="w-2/5 text-center text-sm lg:text-xl rounded-xl  p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">
                Edit/Delete Entries
            </a>

        </div>
    );
}