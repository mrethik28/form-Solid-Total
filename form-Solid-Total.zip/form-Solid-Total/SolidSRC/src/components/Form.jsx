export default function Form(props)
{
    let defval;
    if(props.editForm){defval=props.defaultvalue[1];}
    else{defval=props.defaultvalue[0];}

    async function sendFormData(event)
    {        
        event.preventDefault();
        const data = new FormData(event.target);
        const values= Object.fromEntries(data.entries());
        const val=JSON.stringify(values);
        props.setMyName(values.name);
        document.getElementById('resetbtn').click();
        fetch('/success',{headers:{'Content-Type': 'application/json'}, method:'POST',body:val})
        .then(props.setThanksOpen(true))
       .catch(function(response){alert(response);})
        
    } 

    async function modifyFormData(event)
    {
        event.preventDefault();
        const data = new FormData(event.target);
        const values= Object.fromEntries(data.entries());
        values.id=defval.id;
        const val=JSON.stringify(values);
        props.setMyName(values.name);
        document.getElementById('resetbtn').click();
        fetch('editform',{headers:{'Content-Type': 'application/json'}, method:'POST',body:val})
        .then(()=>{
        props.setEditForm(false);
        props.setListAllForms(false);
    })
       .catch(function(response){alert(response);})

    }

   
    const submitForm= function(event)
    {
        if(props.editForm){
            modifyFormData(event);
        }
        else{
            sendFormData(event);
        }
    }
    return(
        <form onSubmit={submitForm} id="form1" method="POST" class="flex-col bg-white w-4/5 lg:w-3/5 rounded-xl p-4 mt-12">
            <div class="mb-2">
                <label for="name" class="text-md lg:text-xl"> Name:</label>
                <input type="text" required id="name" name="name" value={defval.name} class=" rounded-lg border-black border-solid w-4/5 shadow-md shadow-gray-200 "></input>
            </div>
            
            <div class="mb-2 ">
                <label for="email" class="text-md lg:text-xl">e-Mail:</label>
                <input type="email" name="email" value={defval.email} required placeholder="example@examplemail.com" id="email" class="text-md lg:text-xl p-1 rounded-lg border-black border-solid w-4/5 shadow-md shadow-gray-200"></input>
            </div>
            <div class="mb-2">
                <label for="num" class="text-md lg:text-xl">Phone: </label>
                <input id="num" type="number" name="phonenum" value={defval.phonenum} class=" p-1 rounded-lg border-black border-solid w-4/5 shadow-md shadow-gray-200 text-md lg:text-xl"></input>
            </div>
            <div class=" flex justify-between"> 
                <a class="text-md lg:text-xl">Gender:</a>
                <a><input type="radio" id="m" value="male" name="gender"></input> <label for="m" class="text-md lg:text-xl">Male</label></a>
                <a><input type="radio" id="f" value="female" name="gender"></input> <label for="f" class="text-md lg:text-xl">Female</label></a>
                <a><input type="radio" id="o" value="other" name="gender"></input> <label for="o" class="text-md lg:text-xl">Other</label></a>
            </div>    
            <div>
                <textarea id='txtar' name="contents" placeholder="Please elaborate on your query in less than 100 words" cols="90" rows="10" required maxlength="100" class="resize-none overflow-y-scroll mt-2 w-full border-black border solid rounded-md p-2">{defval.contents}</textarea>
            </div>
            <div class=" mt-2">
                <input id="tc" type="checkbox" name="tnc" required></input><label for="tc" href="tnc.html" target="_blank" class="ml-2">I agree to terms and conditions</label>
            </div>
            <div class="mt-12 lg:mt-8 flex justify-around">
                <button type="submit" form="form1" class=" text-md lg:text-xl w-1/4 rounded-xl p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">Submit</button>
                <button type="reset" id="resetbtn" form="form1" class=" text-md lg:text-xl  w-1/4 rounded-xl p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">Reset</button>
            </div>
        </form>
    )
}