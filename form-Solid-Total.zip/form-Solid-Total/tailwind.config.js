/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./views/*.html"],
  theme: {
    extend: {
      sizing:{
        'oxs':'0px',
      },
      colors:
      {
        nicegray: "#161616",
      },
      spacing:{
        '1/5':'20%',
        '1/6':'16.67%',
      }
    },
    
  },
  plugins: [],
}

