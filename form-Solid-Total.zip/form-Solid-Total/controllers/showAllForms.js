exports.install=function(){
    ROUTE('GET /allforms', getallforms)
}

function getallforms()
{
    let self=this;
    NOSQL('userdata').find().callback(function(err,resp){
        this.json(resp);
        // console.log(resp.items);
        // this.header("Content-Type",'application/json');
        // this.layout("layout");
        // this.view('allforms',{'allData':resp.items})
    }.bind(self));
    
}