exports.install=function(){
    ROUTE('POST /editform', updateForm)
}

function updateForm()
{
    let self=this;
    targetID=self.body.id;
    NOSQL('userdata').modify({'name':self.body.name,'phonenum':self.body.phonenum,'email':self.body.email, 'contents':self.body.contents}).where('id', targetID).callback(function(err,resp){
        this.layout('layout');
        this.view('sample')
    }.bind(self));

}