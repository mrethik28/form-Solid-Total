exports.install = function() {
	ROUTE('POST /allforms',delEntry);
};

function delEntry()
{
    var self=this;
    var targetId=self.body.delid
    NOSQL('userdata').remove().where('id',targetId).callback(function (err,resp){
        // console.log(err);
        NOSQL('userdata').list().callback(function(err,resp){
            const data=resp.items;
            this.json(data)
    //         this.header("Content-Type",'application/json');
    //         this.layout("layout");
    //         this.view('allforms',{'allData':resp.items})
        }.bind(self))

    }.bind(self));
}