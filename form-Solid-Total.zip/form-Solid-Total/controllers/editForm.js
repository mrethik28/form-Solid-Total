exports.install=function(){
    ROUTE('GET /editform', editform)
}

function editform()
{
    let self=this;
    self.layout('layout',{'title':'Edit Your Form'});
    self.view('editform',{'name':self.query.filledName,'phonenum':self.query.filledPhone,'email':self.query.filledEmail, 'contents':self.query.filledContent, 'id':self.query.entryID});    
    
}