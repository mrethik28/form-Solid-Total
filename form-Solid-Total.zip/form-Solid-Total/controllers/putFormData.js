exports.install = function() {
	ROUTE('POST /success',putFormData);
};


function putFormData() {
	var self = this;
    let data=self.body;
    self.json({message:"success"});
    EXEC('+userDetails --> insert', data, function(err,resp){//console.log(err, resp);
    });
    
    // this.redirect('/thanks?name='+data.name,true)
    // let myname=data.name;
	//self.layout("thankslayout");    
    //self.view("thanks",{name:"rethik"},{time:NOW});
    
}


// function f(){
//     var self = this;
//     let data=self.body;
//     let myname=data.name;
//     self.layout("thankslayout");    
//     self.view("thanks",{name:myname},{time:NOW});
// }