//not used at alll


exports.install = function() {
	ROUTE('GET /thanks',showThanks);
	// ROUTE('POST /thanks',showThanks);
};

function showThanks()
{
    let self =this
    // console.log(self.body.name);
    self.json({"name":self.query.name});
	// self.layout("layout");    
    // self.view("thanks",{name:self.query.name});
}