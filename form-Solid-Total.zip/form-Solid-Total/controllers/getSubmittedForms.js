exports.install = function() {
	ROUTE('POST /yourforms',showQueryForm);
};


function showQueryForm() {
	var self = this;
    let data= self.body;
    let myname= data.name;
    //console.log(self);
    // var controller= EXEC('+userDetails --> list', {"name":myname,"email":"x@y.com","gender":"x","message":"","tnc":true}, function(err,resp){
    //     //console.log(err, resp);
    // });
    // console.log(controller);

    NOSQL('userdata').find().where('name',myname).callback(function(err,resp){
        this.header("Content-Type",'application/json');
        this.json(resp);
        ///this.layout("layout");
        //this.json(resp);
        // if(resp){this.view("yourquery",{queryData:resp})}
        // else{this.view("yourquery",{queryData:'1'})};
    }.bind(self));
}