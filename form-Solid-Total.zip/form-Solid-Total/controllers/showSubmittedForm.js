exports.install = function() {
	ROUTE('GET /yourforms',showSubmittedForm);
};


function showSubmittedForm() {
	var self = this;
    self.layout("layout");
	self.view("yourquery",{'queryData':'1'});
	return;	
}