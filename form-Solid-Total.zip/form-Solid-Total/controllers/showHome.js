exports.install = function() {
	ROUTE('GET /',showHome);
	// ROUTE('GET /yourforms',showQueryForm);
};


function showHome() {
	var self = this;
    self.layout("layout");
	self.view("index");
	// self.view("home");
	return;	
}