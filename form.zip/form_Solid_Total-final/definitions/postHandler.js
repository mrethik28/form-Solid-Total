FUNC.postHandler= function(thisObj)
{
    var self=thisObj;
    const command = self.body.commands;
    switch(command)
    {
        case('deleteform'):
            var targetId=self.body.data.delid
            NOSQL('userdata').remove().where('id',targetId).callback(function (err,resp){
                // console.log(err);
                NOSQL('userdata').list().callback(function(err,resp){
                    const data=resp.items;
                    this.json(data)
                }.bind(self))
            }.bind(self));
        break;

        case('getsubmittedforms'):
            var data= self.body.data;
            let myname= data.name;
            NOSQL('userdata').find().where('name',myname).callback(function(err,resp){
                this.header("Content-Type",'application/json');
                this.json(resp);
            }.bind(self));
        break;

        case('putformdata'):
            var data=self.body.data;
            EXEC('+userDetails --> insert', data, function(err,resp){});
        break;

        case('updateform'):
            let targetID=self.body.data.id;
            NOSQL('userdata').modify({'name':self.body.data.name,'phonenum':self.body.data.phonenum,'email':self.body.data.email, 'contents':self.body.data.contents}).where('id', targetID).callback(function(err,resp){
            }.bind(self));
        break;
    }
}

// module.exports =postHandler;