FUNC.getHandler=function(thisObj)
{
    var self=thisObj;
    switch(self.query.command)
    {
        case('allforms'):
            NOSQL('userdata').find().callback(function(err,resp){
                this.json(resp);
            }.bind(self));
        var a;
        break;
        default:
            self.layout("layout");
	        self.view("index");
    }

}