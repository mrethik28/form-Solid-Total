// const postHandler = require('../definitions/postHandler');
exports.install=function(){
    ROUTE('POST /', postHandler);
    ROUTE('GET /', getHandler);
}

function postHandler()
{
    var self=this;
    FUNC.postHandler(self); 
}

function getHandler()
{   
    var self=this;
    FUNC.getHandler(self);

}