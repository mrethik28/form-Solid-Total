const options = {};
options.ip = "localhost";
options.port = "8080";
options.config = { name: 'submitformserver' };

require("total4/debug")(options);
