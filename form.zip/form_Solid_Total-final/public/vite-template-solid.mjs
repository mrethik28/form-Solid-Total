const de = (e, t) => e === t, ue = Symbol("solid-track"), I = {
  equals: de
};
let fe = oe;
const T = 1, M = 2, ee = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var h = null;
let H = null, m = null, y = null, j = null, U = 0;
function P(e, t) {
  const l = m, n = h, s = e.length === 0, i = t === void 0 ? n : t, r = s ? ee : {
    owned: null,
    cleanups: null,
    context: i ? i.context : null,
    owner: i
  }, o = s ? e : () => e(() => N(() => J(r)));
  h = r, m = null;
  try {
    return L(o, !0);
  } finally {
    m = l, h = n;
  }
}
function S(e, t) {
  t = t ? Object.assign({}, I, t) : I;
  const l = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, n = (s) => (typeof s == "function" && (s = s(l.value)), le(l, s));
  return [te.bind(l), n];
}
function O(e, t, l) {
  const n = ne(e, t, !1, T);
  G(n);
}
function X(e, t, l) {
  l = l ? Object.assign({}, I, l) : I;
  const n = ne(e, t, !0, 0);
  return n.observers = null, n.observerSlots = null, n.comparator = l.equals || void 0, G(n), te.bind(n);
}
function N(e) {
  if (m === null)
    return e();
  const t = m;
  m = null;
  try {
    return e();
  } finally {
    m = t;
  }
}
function me(e) {
  return h === null || (h.cleanups === null ? h.cleanups = [e] : h.cleanups.push(e)), e;
}
function te() {
  if (this.sources && this.state)
    if (this.state === T)
      G(this);
    else {
      const e = y;
      y = null, L(() => q(this), !1), y = e;
    }
  if (m) {
    const e = this.observers ? this.observers.length : 0;
    m.sources ? (m.sources.push(this), m.sourceSlots.push(e)) : (m.sources = [this], m.sourceSlots = [e]), this.observers ? (this.observers.push(m), this.observerSlots.push(m.sources.length - 1)) : (this.observers = [m], this.observerSlots = [m.sources.length - 1]);
  }
  return this.value;
}
function le(e, t, l) {
  let n = e.value;
  return (!e.comparator || !e.comparator(n, t)) && (e.value = t, e.observers && e.observers.length && L(() => {
    for (let s = 0; s < e.observers.length; s += 1) {
      const i = e.observers[s], r = H && H.running;
      r && H.disposed.has(i), (r ? !i.tState : !i.state) && (i.pure ? y.push(i) : j.push(i), i.observers && ie(i)), r || (i.state = T);
    }
    if (y.length > 1e6)
      throw y = [], new Error();
  }, !1)), t;
}
function G(e) {
  if (!e.fn)
    return;
  J(e);
  const t = h, l = m, n = U;
  m = h = e, ge(e, e.value, n), m = l, h = t;
}
function ge(e, t, l) {
  let n;
  try {
    n = e.fn(t);
  } catch (s) {
    return e.pure && (e.state = T, e.owned && e.owned.forEach(J), e.owned = null), e.updatedAt = l + 1, re(s);
  }
  (!e.updatedAt || e.updatedAt <= l) && (e.updatedAt != null && "observers" in e ? le(e, n) : e.value = n, e.updatedAt = l);
}
function ne(e, t, l, n = T, s) {
  const i = {
    fn: e,
    state: n,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: h,
    context: h ? h.context : null,
    pure: l
  };
  return h === null || h !== ee && (h.owned ? h.owned.push(i) : h.owned = [i]), i;
}
function se(e) {
  if (e.state === 0)
    return;
  if (e.state === M)
    return q(e);
  if (e.suspense && N(e.suspense.inFallback))
    return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < U); )
    e.state && t.push(e);
  for (let l = t.length - 1; l >= 0; l--)
    if (e = t[l], e.state === T)
      G(e);
    else if (e.state === M) {
      const n = y;
      y = null, L(() => q(e, t[0]), !1), y = n;
    }
}
function L(e, t) {
  if (y)
    return e();
  let l = !1;
  t || (y = []), j ? l = !0 : j = [], U++;
  try {
    const n = e();
    return he(l), n;
  } catch (n) {
    l || (j = null), y = null, re(n);
  }
}
function he(e) {
  if (y && (oe(y), y = null), e)
    return;
  const t = j;
  j = null, t.length && L(() => fe(t), !1);
}
function oe(e) {
  for (let t = 0; t < e.length; t++)
    se(e[t]);
}
function q(e, t) {
  e.state = 0;
  for (let l = 0; l < e.sources.length; l += 1) {
    const n = e.sources[l];
    if (n.sources) {
      const s = n.state;
      s === T ? n !== t && (!n.updatedAt || n.updatedAt < U) && se(n) : s === M && q(n, t);
    }
  }
}
function ie(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const l = e.observers[t];
    l.state || (l.state = M, l.pure ? y.push(l) : j.push(l), l.observers && ie(l));
  }
}
function J(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const l = e.sources.pop(), n = e.sourceSlots.pop(), s = l.observers;
      if (s && s.length) {
        const i = s.pop(), r = l.observerSlots.pop();
        n < s.length && (i.sourceSlots[r] = n, s[n] = i, l.observerSlots[n] = r);
      }
    }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--)
      J(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--)
      e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function be(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function re(e, t = h) {
  throw be(e);
}
const we = Symbol("fallback");
function Y(e) {
  for (let t = 0; t < e.length; t++)
    e[t]();
}
function ye(e, t, l = {}) {
  let n = [], s = [], i = [], r = 0, o = t.length > 1 ? [] : null;
  return me(() => Y(i)), () => {
    let c = e() || [], d, a;
    return c[ue], N(() => {
      let u = c.length, g, $, k, E, F, w, p, v, A;
      if (u === 0)
        r !== 0 && (Y(i), i = [], n = [], s = [], r = 0, o && (o = [])), l.fallback && (n = [we], s[0] = P((B) => (i[0] = B, l.fallback())), r = 1);
      else if (r === 0) {
        for (s = new Array(u), a = 0; a < u; a++)
          n[a] = c[a], s[a] = P(f);
        r = u;
      } else {
        for (k = new Array(u), E = new Array(u), o && (F = new Array(u)), w = 0, p = Math.min(r, u); w < p && n[w] === c[w]; w++)
          ;
        for (p = r - 1, v = u - 1; p >= w && v >= w && n[p] === c[v]; p--, v--)
          k[v] = s[p], E[v] = i[p], o && (F[v] = o[p]);
        for (g = /* @__PURE__ */ new Map(), $ = new Array(v + 1), a = v; a >= w; a--)
          A = c[a], d = g.get(A), $[a] = d === void 0 ? -1 : d, g.set(A, a);
        for (d = w; d <= p; d++)
          A = n[d], a = g.get(A), a !== void 0 && a !== -1 ? (k[a] = s[d], E[a] = i[d], o && (F[a] = o[d]), a = $[a], g.set(A, a)) : i[d]();
        for (a = w; a < u; a++)
          a in k ? (s[a] = k[a], i[a] = E[a], o && (o[a] = F[a], o[a](a))) : s[a] = P(f);
        s = s.slice(0, r = u), n = c.slice(0);
      }
      return s;
    });
    function f(u) {
      if (i[a] = u, o) {
        const [g, $] = S(a);
        return o[a] = $, t(c[a], g);
      }
      return t(c[a]);
    }
  };
}
function x(e, t) {
  return N(() => e(t || {}));
}
const xe = (e) => `Stale read from <${e}>.`;
function ae(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return X(ye(() => e.each, e.children, t || void 0));
}
function C(e) {
  const t = e.keyed, l = X(() => e.when, void 0, {
    equals: (n, s) => t ? n === s : !n == !s
  });
  return X(() => {
    const n = l();
    if (n) {
      const s = e.children;
      return typeof s == "function" && s.length > 0 ? N(() => s(t ? n : () => {
        if (!N(l))
          throw xe("Show");
        return e.when;
      })) : s;
    }
    return e.fallback;
  }, void 0, void 0);
}
function pe(e, t, l) {
  let n = l.length, s = t.length, i = n, r = 0, o = 0, c = t[s - 1].nextSibling, d = null;
  for (; r < s || o < i; ) {
    if (t[r] === l[o]) {
      r++, o++;
      continue;
    }
    for (; t[s - 1] === l[i - 1]; )
      s--, i--;
    if (s === r) {
      const a = i < n ? o ? l[o - 1].nextSibling : l[i - o] : c;
      for (; o < i; )
        e.insertBefore(l[o++], a);
    } else if (i === o)
      for (; r < s; )
        (!d || !d.has(t[r])) && t[r].remove(), r++;
    else if (t[r] === l[i - 1] && l[o] === t[s - 1]) {
      const a = t[--s].nextSibling;
      e.insertBefore(l[o++], t[r++].nextSibling), e.insertBefore(l[--i], a), t[s] = l[i];
    } else {
      if (!d) {
        d = /* @__PURE__ */ new Map();
        let f = o;
        for (; f < i; )
          d.set(l[f], f++);
      }
      const a = d.get(t[r]);
      if (a != null)
        if (o < a && a < i) {
          let f = r, u = 1, g;
          for (; ++f < s && f < i && !((g = d.get(t[f])) == null || g !== a + u); )
            u++;
          if (u > a - o) {
            const $ = t[r];
            for (; o < a; )
              e.insertBefore(l[o++], $);
          } else
            e.replaceChild(l[o++], t[r++]);
        } else
          r++;
      else
        t[r++].remove();
    }
  }
}
const Z = "_$DX_DELEGATE";
function ve(e, t, l, n = {}) {
  let s;
  return P((i) => {
    s = i, t === document ? e() : b(t, e(), t.firstChild ? null : void 0, l);
  }, n.owner), () => {
    s(), t.textContent = "";
  };
}
function _(e, t, l) {
  let n;
  const s = () => {
    const r = document.createElement("template");
    return r.innerHTML = e, l ? r.content.firstChild.firstChild : r.content.firstChild;
  }, i = t ? () => N(() => document.importNode(n || (n = s()), !0)) : () => (n || (n = s())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function V(e, t = window.document) {
  const l = t[Z] || (t[Z] = /* @__PURE__ */ new Set());
  for (let n = 0, s = e.length; n < s; n++) {
    const i = e[n];
    l.has(i) || (l.add(i), t.addEventListener(i, $e));
  }
}
function b(e, t, l, n) {
  if (l !== void 0 && !n && (n = []), typeof t != "function")
    return R(e, t, n, l);
  O((s) => R(e, t(), s, l), n);
}
function $e(e) {
  const t = `$$${e.type}`;
  let l = e.composedPath && e.composedPath()[0] || e.target;
  for (e.target !== l && Object.defineProperty(e, "target", {
    configurable: !0,
    value: l
  }), Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return l || document;
    }
  }); l; ) {
    const n = l[t];
    if (n && !l.disabled) {
      const s = l[`${t}Data`];
      if (s !== void 0 ? n.call(l, s, e) : n.call(l, e), e.cancelBubble)
        return;
    }
    l = l._$host || l.parentNode || l.host;
  }
}
function R(e, t, l, n, s) {
  for (; typeof l == "function"; )
    l = l();
  if (t === l)
    return l;
  const i = typeof t, r = n !== void 0;
  if (e = r && l[0] && l[0].parentNode || e, i === "string" || i === "number")
    if (i === "number" && (t = t.toString()), r) {
      let o = l[0];
      o && o.nodeType === 3 ? o.data = t : o = document.createTextNode(t), l = D(e, l, n, o);
    } else
      l !== "" && typeof l == "string" ? l = e.firstChild.data = t : l = e.textContent = t;
  else if (t == null || i === "boolean")
    l = D(e, l, n);
  else {
    if (i === "function")
      return O(() => {
        let o = t();
        for (; typeof o == "function"; )
          o = o();
        l = R(e, o, l, n);
      }), () => l;
    if (Array.isArray(t)) {
      const o = [], c = l && Array.isArray(l);
      if (K(o, t, l, s))
        return O(() => l = R(e, o, l, n, !0)), () => l;
      if (o.length === 0) {
        if (l = D(e, l, n), r)
          return l;
      } else
        c ? l.length === 0 ? z(e, o, n) : pe(e, l, o) : (l && D(e), z(e, o));
      l = o;
    } else if (t.nodeType) {
      if (Array.isArray(l)) {
        if (r)
          return l = D(e, l, n, t);
        D(e, l, null, t);
      } else
        l == null || l === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      l = t;
    } else
      console.warn("Unrecognized value. Skipped inserting", t);
  }
  return l;
}
function K(e, t, l, n) {
  let s = !1;
  for (let i = 0, r = t.length; i < r; i++) {
    let o = t[i], c = l && l[i], d;
    if (!(o == null || o === !0 || o === !1))
      if ((d = typeof o) == "object" && o.nodeType)
        e.push(o);
      else if (Array.isArray(o))
        s = K(e, o, c) || s;
      else if (d === "function")
        if (n) {
          for (; typeof o == "function"; )
            o = o();
          s = K(e, Array.isArray(o) ? o : [o], Array.isArray(c) ? c : [c]) || s;
        } else
          e.push(o), s = !0;
      else {
        const a = String(o);
        c && c.nodeType === 3 && c.data === a ? e.push(c) : e.push(document.createTextNode(a));
      }
  }
  return s;
}
function z(e, t, l = null) {
  for (let n = 0, s = t.length; n < s; n++)
    e.insertBefore(t[n], l);
}
function D(e, t, l, n) {
  if (l === void 0)
    return e.textContent = "";
  const s = n || document.createTextNode("");
  if (t.length) {
    let i = !1;
    for (let r = t.length - 1; r >= 0; r--) {
      const o = t[r];
      if (s !== o) {
        const c = o.parentNode === e;
        !i && !r ? c ? e.replaceChild(s, o) : e.insertBefore(s, l) : c && o.remove();
      } else
        i = !0;
    }
  } else
    e.insertBefore(s, l);
  return [s];
}
const _e = /* @__PURE__ */ _('<div class=""><h1 class="h-1/5 backdrop:blur-xl absolute top-48 bottom-48 right-96 left-96 w-1/2 p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-6xl text-black shadow-md shadow-yellow-400 rounded-2xl">Thankyou,<!> for submitting !! </h1><button type="button" class="h-10 w-20 bg-white rounded-md p-2 absolute top-0 right-0 text-black hover:text-gray-700 hover:bg-gray-100 ">Go Back');
function Se(e) {
  const t = function() {
    e.setthanksOpen(!1);
  };
  return (() => {
    const l = _e(), n = l.firstChild, s = n.firstChild, i = s.nextSibling;
    i.nextSibling;
    const r = n.nextSibling;
    return b(n, () => e.name, i), r.$$click = t, l;
  })();
}
V(["click"]);
const ke = /* @__PURE__ */ _('<form id="form1" method="POST" class="flex-col bg-white w-4/5 lg:w-3/5 rounded-xl p-4 mt-12"><div class="mb-2"><label for="name" class="text-md lg:text-xl"> Name:</label><input type="text" required id="name" name="name" class=" rounded-lg border-black border-solid w-4/5 shadow-md shadow-gray-200 "></div><div class="mb-2 "><label for="email" class="text-md lg:text-xl">e-Mail:</label><input type="email" name="email" required placeholder="example@examplemail.com" id="email" class="text-md lg:text-xl p-1 rounded-lg border-black border-solid w-4/5 shadow-md shadow-gray-200"></div><div class="mb-2"><label for="num" class="text-md lg:text-xl">Phone: </label><input id="num" type="number" name="phonenum" class=" p-1 rounded-lg border-black border-solid w-4/5 shadow-md shadow-gray-200 text-md lg:text-xl"></div><div class=" flex justify-between"><a class="text-md lg:text-xl">Gender:</a><a><input type="radio" id="m" value="male" name="gender"> <label for="m" class="text-md lg:text-xl">Male</label></a><a><input type="radio" id="f" value="female" name="gender"> <label for="f" class="text-md lg:text-xl">Female</label></a><a><input type="radio" id="o" value="other" name="gender"> <label for="o" class="text-md lg:text-xl">Other</label></a></div><div><textarea id="txtar" name="contents" placeholder="Please elaborate on your query in less than 100 words" cols="90" rows="10" required maxlength="100" class="resize-none overflow-y-scroll mt-2 w-full border-black border solid rounded-md p-2"></textarea></div><div class=" mt-2"><input id="tc" type="checkbox" name="tnc" required><label for="tc" href="tnc.html" target="_blank" class="ml-2">I agree to terms and conditions</label></div><div class="mt-12 lg:mt-8 flex justify-around"><button type="submit" form="form1" class=" text-md lg:text-xl w-1/4 rounded-xl p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">Submit</button><button type="reset" id="resetbtn" form="form1" class=" text-md lg:text-xl w-1/4 rounded-xl p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">Reset');
function Ae(e) {
  let t;
  e.editForm ? t = e.defaultvalue[1] : t = e.defaultvalue[0];
  async function l(i) {
    i.preventDefault();
    const r = new FormData(i.target), o = Object.fromEntries(r.entries()), c = JSON.stringify({
      commands: "putformdata",
      data: o
    });
    e.setMyName(o.name), document.getElementById("resetbtn").click(), fetch("/", {
      headers: {
        "Content-Type": "application/json"
      },
      method: "POST",
      body: c
    }).then(e.setThanksOpen(!0)).catch(function(d) {
      alert();
    });
  }
  async function n(i) {
    i.preventDefault();
    const r = new FormData(i.target), o = Object.fromEntries(r.entries());
    o.id = t.id;
    const c = JSON.stringify({
      commands: "updateform",
      data: o
    });
    e.setMyName(o.name), document.getElementById("resetbtn").click(), console.log(c), fetch("/", {
      headers: {
        "Content-Type": "application/json"
      },
      method: "POST",
      body: c
    }).then(() => {
      e.setEditForm(!1), e.setListAllForms(!1);
    }).catch(function(d) {
      alert(d);
    });
  }
  const s = function(i) {
    e.editForm ? n(i) : l(i);
  };
  return (() => {
    const i = ke(), r = i.firstChild, o = r.firstChild, c = o.nextSibling, d = r.nextSibling, a = d.firstChild, f = a.nextSibling, u = d.nextSibling, g = u.firstChild, $ = g.nextSibling, k = u.nextSibling, E = k.nextSibling, F = E.firstChild;
    return i.addEventListener("submit", s), b(F, () => t.contents), O(() => c.value = t.name), O(() => f.value = t.email), O(() => $.value = t.phonenum), i;
  })();
}
const Ee = /* @__PURE__ */ _('<div class="flex justify-center"><h1 class=" mt-12 lg:mt-4 text-3xl rounded-xl p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300 ">Post Your Query '), Fe = /* @__PURE__ */ _('<div class=" w-2/5 flex justify-between absolute bottom-1/6 lg:bottom-4 mx-auto mt-12 lg:mt-16"><a class="hover:cursor-pointer w-2/5 text-center text-sm lg:text-xl rounded-xl p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">View Submitted Forms</a><a class="hover:cursor-pointer w-2/5 text-center text-sm lg:text-xl rounded-xl p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">Edit/Delete Entries'), Ce = /* @__PURE__ */ _('<div class="pb-24 mx-auto lg:w-2/5 w-full mt-4 lg:mt-4 h-4/5 flex justify-center bg-gradient-to-b from-gray-800 to nicegray shadow-2xl shadow-black rounded-3xl">');
function je(e) {
  const t = function() {
    e.setNeedForm(!0);
  }, l = function() {
    e.setListAllForms(!0);
  }, [n, s] = S(!1), [i, r] = S(""), o = {
    name: "",
    phonenum: "",
    email: "",
    contents: ""
  };
  return x(C, {
    get when() {
      return n();
    },
    get fallback() {
      return [Ee(), (() => {
        const c = Ce();
        return b(c, x(Ae, {
          setThanksOpen: s,
          get setListAllForms() {
            return e.setListAllForms;
          },
          get setEditForm() {
            return e.setEditForm;
          },
          get editForm() {
            return e.editForm;
          },
          setMyName: r,
          get defaultvalue() {
            return [o, e.editDetails];
          }
        }), null), b(c, x(C, {
          get when() {
            return !e.editForm;
          },
          get children() {
            const d = Fe(), a = d.firstChild, f = a.nextSibling;
            return a.$$click = t, f.$$click = l, d;
          }
        }), null), c;
      })()];
    },
    get children() {
      return x(Se, {
        setthanksOpen: s,
        name: i
      });
    }
  });
}
V(["click"]);
const Ne = /* @__PURE__ */ _('<div id="mytable" class="close overflow-scroll absolute top-48 left-96 right-96 shadow-lg shadow-black content-start w-1/2 h-3/5 m-auto grid grid-cols-1 grid-auto auto-cols-auto gap-x-8 gap-y-4 bg-nicegray rounded-2xl p-6 text-yellow-300"><button type="button" class="h-10 w-10 top-0 right-0 absolute bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-700 hover:bg-gray-100 ">X</button><div class="flex justify-between"><div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">Name</div><div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">Phone</div><div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">eMail</div><div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">Gender</div>'), Te = /* @__PURE__ */ _(`<div id="'rest" class="w-screen h-screen bg-nicegray flex flex-wrap justify-center items-center "><label for="myname" class="w-auto h-auto lg:w-1/5 p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-md lg:text-2xl text-black shadow-md shadow-yellow-400 rounded-2xl">Enter Name:</label><form id="f1"><input id="myname" name="name" type="text" required class=" text-black ml-10 mr-5 w-45 h-auto rounded-2xl text-lg font-redix z-"><button type="submit" form="f1" class="w-auto p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-md lg:text-xl text-black shadow-md shadow-yellow-400 rounded-2xl"> Submit</button></form><button type="button" class="absolute top-0 right-0 w-auto h-auto p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-md lg:text-xl text-black shadow-md shadow-yellow-400 rounded-2xl"> Go Back`), De = /* @__PURE__ */ _('<div class="flex justify-around"><a></a><a></a><a></a><a>');
function Oe(e) {
  async function t(r) {
    r.preventDefault();
    let o = String(document.getElementById("myname").value), c = o.charAt(0).toUpperCase() + o.slice(1);
    document.getElementById("myname").value = c;
    const a = {
      name: new FormData(r.target).get("name")
    }, f = JSON.stringify({
      commands: "getsubmittedforms",
      data: a
    }), u = await fetch("/", {
      headers: {
        "Content-Type": "application/json"
      },
      method: "POST",
      body: f
    });
    if (u.ok) {
      const g = await u.json();
      n(g);
    } else
      alert("error:" + u.status);
  }
  const [l, n] = S(!1), s = function() {
    n(!1);
  }, i = function() {
    e.setNeedForm(!1);
  };
  return x(C, {
    get when() {
      return l();
    },
    get fallback() {
      return (() => {
        const r = Te(), o = r.firstChild, c = o.nextSibling, d = c.nextSibling;
        return c.addEventListener("submit", t), d.$$click = i, r;
      })();
    },
    get children() {
      const r = Ne(), o = r.firstChild;
      return o.nextSibling, o.$$click = s, b(r, x(ae, {
        get each() {
          return l();
        },
        children: (c) => (() => {
          const d = De(), a = d.firstChild, f = a.nextSibling, u = f.nextSibling, g = u.nextSibling;
          return b(a, () => c.name), b(f, () => c.phonenum), b(u, () => c.email), b(g, () => c.gender), d;
        })()
      }), null), r;
    }
  });
}
V(["click"]);
const Le = /* @__PURE__ */ _('<div class="w-screen h-screen bg-nicegray pt-20"><button type="button" class="absolute top-0 right-0 text-white bg-black p-2 text-2xl">X</button><div class="m-6 mt-0 w-1/4 mx-auto flex justify-around"><button type="button" class="text-yellow-300 bg-gray-700 p-2 mt-16 rounded-xl w-full ">Edit</button><button type="button" class="text-yellow-300 bg-gray-700 p-2 rounded-xl w-full mt-16 ">Delete</button></div><div id="mytable" class="absolute bottom-16 left-96 right-96 shadow-lg overflow-scroll shadow-black content-start w-1/2 h-3/5 m-auto grid grid-cols-1 grid-auto auto-cols-auto gap-x-8 gap-y-4 bg-gradient-to-b from-nicegray to-gray-800 rounded-2xl p-6 text-yellow-300"><div class="flex flex-nowrap w-full justify-between cursor-pointer"><div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">Name</div><div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">Phone</div><div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">eMail</div><div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">Gender</div><div class="flex justify-center content-center bg-gray-950 rounded-2xl p-2 w-1/5">id</div></div><div>'), Be = /* @__PURE__ */ _('<div class="flex focus:ring-2 focus:ring-white focus:ring-opacity-50 active:ring-2 active:ring-white active:ring-opacity-50 my-2 w-full justify-between cursor-pointer border-solid border-10 border-black rounded-xl px-2"><a></a><a></a><a></a><a></a><a></a><a>');
function Pe(e) {
  const t = function() {
    e.setListAllForms(!1);
  }, [l, n] = S([]), [s, i] = S(), r = async function() {
    const a = await fetch("/?command=allforms");
    if (a.ok) {
      const f = await a.json();
      n(f);
    } else
      alert("error:");
  };
  r();
  function o(a) {
    i(a.record.id), e.setEditDetails(a.record);
  }
  const c = async function(a) {
    const f = JSON.stringify({
      commands: "deleteform",
      data: {
        delid: s()
      }
    });
    (await fetch("/", {
      headers: {
        "Content-Type": "application/json"
      },
      method: "POST",
      body: f
    })).ok ? r() : alert("error");
  }, d = function() {
    e.setEditForm(!0), e.setListAllForms(!1);
  };
  return (() => {
    const a = Le(), f = a.firstChild, u = f.nextSibling, g = u.firstChild, $ = g.nextSibling, k = u.nextSibling, E = k.firstChild, F = E.nextSibling;
    return f.$$click = t, g.$$click = d, $.$$click = c, b(F, x(ae, {
      get each() {
        return l();
      },
      children: (w) => (() => {
        const p = Be(), v = p.firstChild, A = v.nextSibling, B = A.nextSibling, Q = B.nextSibling, W = Q.nextSibling, ce = W.nextSibling;
        return p.$$click = () => o({
          record: w
        }), b(v, () => w.name), b(A, () => w.phonenum), b(B, () => w.email), b(Q, () => w.gender), b(W, () => w.id), b(ce, () => w.contents), p;
      })()
    })), a;
  })();
}
V(["click"]);
const Ie = /* @__PURE__ */ _('<div class="bg-nicegray w-screen h-screen">');
function Me() {
  const [e, t] = S(!1), [l, n] = S(!1), [s, i] = S(!1), [r, o] = S();
  return (() => {
    const c = Ie();
    return b(c, x(C, {
      get when() {
        return !e();
      },
      get children() {
        return [x(C, {
          get when() {
            return !s();
          },
          get children() {
            return x(je, {
              setNeedForm: t,
              get editForm() {
                return l();
              },
              setdEditForm: n,
              setListAllForms: i,
              get editDetails() {
                return r();
              }
            });
          }
        }), x(C, {
          get when() {
            return s();
          },
          get children() {
            return x(Pe, {
              setListAllForms: i,
              setEditForm: n,
              setEditDetails: o
            });
          }
        })];
      }
    }), null), b(c, x(C, {
      get when() {
        return e();
      },
      get children() {
        return x(Oe, {
          setNeedForm: t
        });
      }
    }), null), c;
  })();
}
const qe = document.getElementById("root");
ve(() => x(Me, {}), qe);
