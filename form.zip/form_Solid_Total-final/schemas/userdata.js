NEWSCHEMA('userDetails', function(schema){
    schema.define('name','Name(20)',true);
    schema.define('phonenum', 'Number');
    schema.define('email','Email',true);
    schema.define('gender','String(6)');
    schema.define('contents','String');
    schema.define('tnc','Boolean', true);
    schema.define('id',UID, true)(() => UID());

    schema.setInsert(function($,model){
        // console.log(model); 
        model.dateofentry=NOW;
        model.id=UID();
        NOSQL('userdata').insert(model).callback(//$.done(model.id)
        );    
        // $.redirect('/thanks')
    });
    schema.setList(function($,model){
        //console.log(model); 
        //NOSQL('userdata').find().where('name',model.name).callback(function(err,resp){
            //console.log(resp);
           // return resp;
        });
});    
        
    // schema.addWorkflow('nameget',function($){
    //     NOSQL('userdata').find().where('name',model.name);
    // });

