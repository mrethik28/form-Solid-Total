import Frame from "./components/Frame";
import Findform from "./components/Findform";
import { Show, createSignal } from "solid-js";
import ListAll from "./components/ListAll";

function App() {
  const [needForm, setNeedForm]=createSignal(false);
  const [editForm, setEditForm]=createSignal(false);
  const [listAllForms, setListAllForms]=createSignal(false);
  const [editDetails, setEditDetails]=createSignal();

  return (    
    <div class="bg-nicegray w-screen h-screen">
    <Show when={!needForm()}>
      <Show when={!listAllForms()}>
      <Frame setNeedForm={setNeedForm} editForm={editForm()} setdEditForm={setEditForm} setListAllForms={setListAllForms} editDetails = {editDetails()} />
      </Show>
      <Show when={listAllForms()}>
      <ListAll setListAllForms={setListAllForms} setEditForm={setEditForm} setEditDetails={setEditDetails}/>
      </Show>
    </Show>
    <Show when={needForm()}>
      <Findform setNeedForm={setNeedForm}/>
    </Show>
    </div>
);

  
}

export default App;
