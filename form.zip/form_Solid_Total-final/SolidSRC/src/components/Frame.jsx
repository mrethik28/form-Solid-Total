import { Show, createSignal, onMount } from "solid-js";
import Thanks from "./Thanks.jsx";
import Form from "./Form.jsx";

export default function Frame(props){

    const bringFind = function(){
        props.setNeedForm(true);
    }
    const bringAll= function(){
        props.setListAllForms(true);
    }
    
    const [thanksOpen, setThanksOpen]=createSignal(false);  
    const [myName, setMyName]= createSignal("");
    
    
    // onMount(async () => {
    //     {console.log(thanksOpen())}
        
    //   });
    const emptydata={"name":"","phonenum":"","email":"","contents":""};
    return(
        
        <Show when={thanksOpen()}
        fallback={
            <>
        <div class="flex justify-center">
        <h1 class=" mt-12 lg:mt-4 text-3xl rounded-xl p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300 ">
            Post Your Query 
        </h1>
        </div>
        <div class="pb-24 mx-auto lg:w-2/5 w-full mt-4 lg:mt-4 h-4/5 flex justify-center bg-gradient-to-b from-gray-800 to nicegray shadow-2xl shadow-black rounded-3xl">
        
        <Form setThanksOpen={setThanksOpen} setListAllForms={props.setListAllForms} setEditForm={props.setEditForm} editForm={props.editForm} setMyName={setMyName} defaultvalue={[emptydata,props.editDetails]}/>

        <Show when={!props.editForm}>
        <div class=" w-2/5 flex justify-between absolute bottom-1/6 lg:bottom-4 mx-auto mt-12 lg:mt-16">
            <a onClick={bringFind}  class="hover:cursor-pointer  w-2/5 text-center text-sm lg:text-xl rounded-xl  p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">
                View Submitted Forms
            </a>
            <a onClick={bringAll} class="hover:cursor-pointer w-2/5 text-center text-sm lg:text-xl rounded-xl  p-4 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 shadow-md shadow-yellow-300">
                Edit/Delete Entries
            </a>
        </div>
        </Show>
        
        </div>
        </>
        } >
            <Thanks setthanksOpen={setThanksOpen} name={myName} />
        </Show>
        


        
                   
    );    
}
