export default function Thanks(props)
{
    const closeThanks= function()
    {
        props.setthanksOpen(false);}     
    return(
        <div class="">
            <h1 class ="h-1/5 backdrop:blur-xl absolute top-48 bottom-48 right-96 left-96 w-1/2 p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-6xl text-black shadow-md shadow-yellow-400 rounded-2xl">
                Thankyou,{props.name} for submitting !!        
            </h1>
            <button type="button" onClick={closeThanks} class="h-10 w-20 bg-white rounded-md p-2 absolute top-0 right-0 text-black hover:text-gray-700 hover:bg-gray-100 " >Go Back</button>
        </div>
        )
}