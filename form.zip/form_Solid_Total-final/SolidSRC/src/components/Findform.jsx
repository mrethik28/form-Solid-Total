import { For, Show, createSignal } from "solid-js";

export default function Findform(props)
{
    async function putName(event){
        event.preventDefault();
        let a =String(document.getElementById('myname').value);
        let b = a.charAt(0).toUpperCase() + a.slice(1);
        document.getElementById('myname').value=b;
        const formdata = new FormData(event.target);
        const data= {'name':formdata.get('name')};
        const sendData= JSON.stringify({'commands':'getsubmittedforms','data':data})
        const response = await fetch('/',{headers:{'Content-Type':'application/json'},method:'POST',body:sendData});
        if(response.ok)
        {
            const jsondata = await response.json();
            setRecords(jsondata);
        }
        else{
            alert("error:"+ response.status);
        }
    }


    const [records, setRecords]= createSignal(false);


    const closeRec = function(){setRecords(false);}

    const goBackFunc = function(){
        props.setNeedForm(false);
    }
    return(

<Show when={records()}
fallback={
    <div id="'rest" class="w-screen h-screen bg-nicegray flex flex-wrap justify-center items-center ">
    <label for="myname" class ="w-auto h-auto lg:w-1/5 p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-md lg:text-2xl text-black shadow-md shadow-yellow-400 rounded-2xl">
            Enter Name:
    </label>
    
    <form id="f1" onSubmit={putName}>
        <input id="myname" name="name" type="text" required class=" text-black ml-10 mr-5 w-45 h-auto rounded-2xl text-lg font-redix z-"></input>
        <button type="submit" form="f1" class ="w-auto p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-md lg:text-xl text-black shadow-md shadow-yellow-400 rounded-2xl"> Submit</button>
    </form>
    <button onClick={goBackFunc} type="button" class ="absolute top-0 right-0 w-auto h-auto p-2 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-yellow-200 via-yellow-300 to-yellow-400 text-center font-redix text-md lg:text-xl text-black shadow-md shadow-yellow-400 rounded-2xl"> Go Back</button>

</div>
}>
<div id="mytable" class="close overflow-scroll absolute top-48 left-96 right-96 shadow-lg shadow-black content-start w-1/2 h-3/5 m-auto grid grid-cols-1 grid-auto auto-cols-auto gap-x-8 gap-y-4 bg-nicegray rounded-2xl p-6 text-yellow-300">
    <button type="button" onClick={closeRec} class="h-10 w-10 top-0 right-0 absolute bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-700 hover:bg-gray-100 " >X</button>
    <div class="flex justify-between">    
    <div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">Name</div>    
    <div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">Phone</div>    
    <div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">eMail</div>    
    <div class="bg-gray-950 rounded-2xl p-2 w-1/5 flex justify-center">Gender</div>    
    </div>
    <For each={records()}>{record =>(
    <div class="flex justify-around">
        <a>{record.name}</a>
        <a>{record.phonenum}</a>
        <a>{record.email}</a>
        <a>{record.gender}</a>
    </div>
    )}</For>
</div>
</Show>

    );
}